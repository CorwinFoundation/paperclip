#!/bin/sh
set -eu

test "$(id -u)" -eq 0
gpasswd -d passive-demo-deploy backbond-judge-client >/dev/null 2>&1 || true
setfacl -x g:backbond-judge-client /run/backbond-claude-judge 2>/dev/null || true
setfacl -d -x g:backbond-judge-client /run/backbond-claude-judge 2>/dev/null || true
rm -f /etc/sysusers.d/backbond-judge-client.conf
rm -f /etc/tmpfiles.d/backbond-claude-judge.conf
rm -f /etc/systemd/system/backbond-claude-judge.service.d/20-judge-client-runtime.conf
systemctl daemon-reload

# Deliberately retain the now-unused group: deleting a group can reassign its
# numeric GID later and make stale filesystem entries unsafe. An operator may
# remove it only after a host-wide numeric-GID ownership audit.
