#!/bin/sh
set -eu

test "$(id -u)" -eq 0
src=${1:?candidate directory required}
install -d -o root -g root -m 0755 /etc/systemd/system/backbond-claude-judge.service.d
install -o root -g root -m 0644 "$src/00-backbond-judge-client.conf" /etc/sysusers.d/backbond-judge-client.conf
install -o root -g root -m 0644 "$src/10-backbond-claude-judge.conf" /etc/tmpfiles.d/backbond-claude-judge.conf
install -o root -g root -m 0644 "$src/20-judge-client-runtime.conf" /etc/systemd/system/backbond-claude-judge.service.d/20-judge-client-runtime.conf
systemd-sysusers /etc/sysusers.d/backbond-judge-client.conf
usermod -a -G backbond-judge-client passive-demo-deploy
systemd-tmpfiles --create /etc/tmpfiles.d/backbond-claude-judge.conf
# Apply the inherited socket capability to the already-live socket. Future
# sockets receive the same entry from the directory's default ACL.
setfacl -m g:backbond-judge-client:rw- /run/backbond-claude-judge/judge.sock
systemctl daemon-reload

# No service restart is performed. Existing and new forced-command SSH sessions
# receive the supplementary group; the existing socket receives the access ACL.
