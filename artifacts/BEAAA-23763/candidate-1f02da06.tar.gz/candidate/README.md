# BEAAA-23759 immutable judge-socket repair candidate

BLUF: grant `passive-demo-deploy` only the ability to traverse the judge runtime directory and open its Unix socket, through a dedicated supplementary group and persistent access-control entries. Do not add the principal to `backbond-demo`.

## Classification and contract

- Deliverable: an internal host-configuration candidate for independent QA that repairs judge-socket access without installing, restarting, arming, dispatching, or deploying.
- Classification: rule-execution under `scanner-implementation-supervision-v1.md`; no rubric, judge selection, score math, output shape, or corpus semantics change. Because the boundary is security-sensitive, installation remains subject to CTO/security-owner review and the canonical QA child.
- Scanner contract: `contracts/are-scanner-api-v1.md@v1.3.0` (parent pin). Output shape is unchanged.
- Calibration: N=5 not run; host Unix permissions cannot affect scoring semantics and this candidate is not installed. Delta is `N/A (non-scoring host access configuration)`.

## Privilege inventory

Names and metadata only, based on the incident evidence supplied with the issue:

| Boundary | Existing metadata | Consequence of broad `backbond-demo` membership | Candidate result |
|---|---|---|---|
| Judge runtime directory | `/run/backbond-claude-judge`, `root:backbond-demo`, `0750` | Traverse and list every current/future runtime entry readable by that group | Traverse only via named ACL; no directory read/list permission |
| Judge socket | `judge.sock`, `root:backbond-demo`, `0660` | Read/write access | Read/write access via inherited named ACL, the required capability |
| Judge service | `backbond-claude-judge.service`, `root:backbond-demo`, active | Potential access to any other group-readable service resources | No service-group membership; no start/stop/restart permission added |
| Protected environment | `/etc/backbond/real-agent-demo.env`, protected | Possible exposure if any path is group-readable by `backbond-demo` now or later | No new ACL, ownership, mode, or group change |
| Fixed helper | root-owned forced command and bounded sudo command | Unchanged | Unchanged |
| Docker | deploy principal already belongs to `docker` per incident evidence | Existing high-privilege boundary; out of scope and not expanded | Unchanged |
| SSH | forced-command key | Broad group membership could expose group-readable host resources | Key and command unchanged; only the dedicated group is added |
| One-shot gates | GitHub variable and host markers absent | A retry could consume or alter authorization | Installer and verifier do not arm, dispatch, or create markers |

No secret values, key material, environment contents, socket payloads, or unrelated resource names are inventoried.

## Restart model

`systemd-sysusers` creates the stable dedicated group. `systemd-tmpfiles` creates the runtime directory at boot with its access and default access-control entries. The systemd drop-in preserves that directory across judge-service stops/restarts. A newly created `judge.sock` inherits `rw-` for the dedicated group while retaining `root:backbond-demo` ownership and `0660` mode. The installer applies the same entries to the current directory and socket without restarting the service.

## Install and impact

Run only after independent QA approves the exact archive hash:

```sh
sudo ./install.sh "$(pwd)"
sudo ./verify-host.sh
```

Installation writes three root-owned `0644` configuration files, adds one supplementary group membership, refreshes access-control entries, and runs `daemon-reload`. It does not restart the service. Existing SSH sessions may need reconnection to acquire the new group.

## Rollback

```sh
sudo ./rollback.sh
```

Rollback removes the membership, current access-control entries, and configuration files, then reloads systemd. It does not restart the live service or delete the numeric group. The drop-in's `RuntimeDirectoryPreserve=yes` remains effective until `daemon-reload` completes, then the original service definition governs the next service lifecycle.

## QA acceptance

QA must confirm exact hashes, root ownership/modes after staged installation, dedicated-group membership without `backbond-demo`, runtime and socket ACLs, protected-env denial, no widened sudo/SSH/root access, active service health, absent one-shot markers, and success of the already-pinned helper preflight. QA must test an isolated host-equivalent first; production installation belongs to BEAAA-23764 and is prohibited by this issue.

## Operational metadata

- ticket: `BEAAA-23759`
- scanner_version: parent-pinned immutable d9 candidate; unchanged by this package
- corpus_version: unchanged / not touched
- probe-set-version: unchanged / not touched
- rubric_point_id: `N/A` (host access boundary)
- N=5 calibration delta: `N/A` (no scoring execution or semantics)
- cto_cosign_ref: required before installation because the work touches tamper-resistance and host privilege boundaries
- FAL audit: internal engineering artifact; factual claims limited to issue-supplied evidence and candidate bytes
