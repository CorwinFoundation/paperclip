#!/bin/sh
set -eu

fail() { printf 'FAIL %s\n' "$1" >&2; exit 1; }
pass() { printf 'PASS %s\n' "$1"; }

test "$(id -u)" -eq 0 || fail root_required
getent group backbond-judge-client | awk -F: '$4 ~ /(^|,)passive-demo-deploy(,|$)/ {ok=1} END {exit !ok}' || fail dedicated_group_membership
! id -nG passive-demo-deploy | tr ' ' '\n' | grep -Fxq backbond-demo || fail broad_group_membership
pass group_boundary

test "$(stat -c '%U:%G %a' /run/backbond-claude-judge)" = 'root:backbond-demo 750' || fail runtime_owner_mode
test "$(stat -c '%U:%G %a' /run/backbond-claude-judge/judge.sock)" = 'root:backbond-demo 660' || fail socket_owner_mode
getfacl -cp /run/backbond-claude-judge | grep -Fxq 'group:backbond-judge-client:--x' || fail directory_acl
getfacl -cp /run/backbond-claude-judge/judge.sock | grep -Eq '^group:backbond-judge-client:rw-' || fail socket_acl
pass socket_boundary

runuser -u passive-demo-deploy -- test ! -r /etc/backbond/real-agent-demo.env || fail protected_env_readable
runuser -u passive-demo-deploy -- sh -c '! find /etc/backbond -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null | grep -q .' || fail protected_directory_listable
sudo -l -U passive-demo-deploy | grep -Fq '/usr/local/sbin/backbond-real-agent-demo-deploy' || fail fixed_helper_missing
! sudo -l -U passive-demo-deploy | grep -Eq 'ALL[[:space:]]*\)|NOPASSWD:[[:space:]]*ALL' || fail broad_sudo
pass secret_and_sudo_boundaries

systemctl is-active --quiet backbond-claude-judge.service || fail judge_service_unhealthy
test -S /run/backbond-claude-judge/judge.sock || fail socket_absent
test ! -e /var/lib/backbond-real-agent-demo/d9-one-shot.armed || fail host_arm_marker_present
test ! -e /var/lib/backbond-real-agent-demo/d9-one-shot.consumed || fail host_consumed_marker_present
pass health_and_one_shot_boundaries

# The readiness/client request itself must be supplied by the already-pinned
# deployment helper. This verifier intentionally does not synthesize protocol
# bytes or disclose tokens. Execute the helper's preflight as the deploy user.
runuser -u passive-demo-deploy -- sudo -n /usr/local/sbin/backbond-real-agent-demo-deploy preflight || fail pinned_client_preflight
pass pinned_client_preflight
