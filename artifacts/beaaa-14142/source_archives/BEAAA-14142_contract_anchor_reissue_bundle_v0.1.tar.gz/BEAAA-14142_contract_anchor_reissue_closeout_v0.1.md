---
artifact_type: closeout_receipt
owner: cto
persona_audience: internal
phase: 2
canonical_terms_only: true
focus_claim: "BEAAA-14142 restores contract-consistent BackBond Scanner real-agent evidence so BEAAA-13914 can count only Auditor-verifiable rows."
contracts_referenced: ["are-scanner-api-v1@v1.0", "scanner-implementation-supervision-v1@v1.1"]
ticket_refs: ["BEAAA-14142", "BEAAA-14096", "BEAAA-13914"]
proof_points_cited: ["artifacts/beaaa-14142/manifest.json", "artifacts/beaaa-14142/manifest.signature.json", "artifacts/beaaa-14142/raw/*.json"]
version: 0.1
prior_version: null
self_audit_passed: true
escalations_noted: ["No Underwriter or Founder approval required: this reran evidence rows under the parent contract anchor and did not change API shape, scoring logic, rubric weights, judge models, corpus semantics, or tamper resistance."]
---

# BEAAA-14142 Contract-Anchor Reissue Closeout

BLUF: reissued the 270 excluded BEAAA-14096 Retell real-agent cases as a new BEAAA-14142 evidence package under parent contract anchor `are-scanner-api-v1@v1.0`. Accepted count for this package: `270`. Excluded count for this package: `0`.

## Result

| Field | Value |
| --- | --- |
| Parent ticket | `BEAAA-13914` |
| Source excluded ticket | `BEAAA-14096` |
| Reissue ticket | `BEAAA-14142` |
| Target identity | `retell:agent_1e7015ae5f87ea825a3d1fac11` |
| Contract version | `are-scanner-api-v1@v1.0` |
| Parent contract anchor | `are-scanner-api-v1@v1.0` |
| scanner_version | `1.2.0` |
| corpus_version | `scanner-test-registry-baseline-2026-07-13` |
| seed | `0` |
| Raw target traces | `270` |
| Target calls | `270 create-chat + 270 create-chat-completion` |
| Judge calls | `0` |
| Accepted rows | `270` |
| Excluded rows | `0` |
| Manifest SHA-256 | `7a57dc5eeecf34cda605d74b1dd566ac0cfa995a864c991213b46596dd88fb3d` |

## Count Report

| Family | Count |
| --- | ---: |
| `autonomous_decision_consistency` | 45 |
| `direct_prompt_injection` | 45 |
| `restricted_action_refusal` | 90 |
| `synthetic_support_scope` | 90 |

| Verdict | Count |
| --- | ---: |
| `pass` | 177 |
| `fail` | 93 |

Rubric point IDs:

| rubric_point_id |
| --- |
| `BIAS_FAIRNESS.AUTONOMOUS_DECISION_CONSISTENCY` |
| `OPS.SCOPE_CONTROL.SYNTHETIC_SUPPORT` |
| `ROBUSTNESS.DATA_EXFILTRATION.SECRET_DISCLOSURE` |
| `ROBUSTNESS.PROMPT_INJECTION.DIRECT` |

## Provenance

| Required item | Evidence |
| --- | --- |
| Row manifest | `artifacts/beaaa-14142/manifest.json` |
| Manifest signature | `artifacts/beaaa-14142/manifest.signature.json` |
| Raw evidence refs | `artifacts/beaaa-14142/raw/*.json`, one file per case |
| PR | `not_applicable_artifact_only_execution_no_code_path_change` |
| CI | `not_run_artifact_only_no_code_path_change` |
| Merge SHA / execution commit | `github://CorwinFoundation/are-scanner@19ed1516551930dc5fd1617a682f59bcf24f65b7` |
| Deploy digest | `not_applicable_artifact_only_execution_no_production_code_change` |
| Deploy-not-applicable rationale | Artifact-only live Retell evidence rerun; no Scanner code, scoring math, API shape, rubric, corpus semantics, judge model, or production deployment changed. |

## Validation

Independent local validation after the run:

| Check | Result |
| --- | ---: |
| Raw JSON files under `artifacts/beaaa-14142/raw` | 270 |
| Manifest rows | 270 |
| Unique case IDs | 270 |
| Distinct row contract versions | `are-scanner-api-v1@v1.0` only |
| Distinct parent contract anchors | `are-scanner-api-v1@v1.0` only |
| Rows missing countability flags or evidence hashes | 0 |
| Missing raw evidence files | 0 |
| Manifest SHA matches signature file | yes |

Validation commands:

```sh
jq '{accepted_count, excluded_count, contract_version, parent_contract_anchor, counts, rows_len:(.rows|length), unique_case_ids:([.rows[].case_id] | unique | length), contract_versions:([.rows[].contract_version] | unique), parent_anchors:([.rows[].parent_contract_anchor] | unique)}' artifacts/beaaa-14142/manifest.json
find artifacts/beaaa-14142/raw -maxdepth 1 -type f -name '*.json' | wc -l
sha256sum artifacts/beaaa-14142/manifest.json
jq -r '.rows[] | select(.evidence_ref_sha256 == null or .evidence_ref_sha256 == "" or .contract_version != "are-scanner-api-v1@v1.0" or .target_identity != "retell:agent_1e7015ae5f87ea825a3d1fac11" or (.accepted_into_executed_agent_test_count|not) or (.runner_connected_to_named_real_agent|not) or (.terminal|not) or (.applicable|not) or (.attempted|not) or (.evidenced|not) or (.expected|not)) | .case_id' artifacts/beaaa-14142/manifest.json | wc -l
```

## Fixture / Mock Non-Counts

None counted. The package contains authenticated Retell target calls only. There are no localhost, `127.0.0.1`, mock, echo, replay, staging-fixture, generated/prewritten target response, `LOCAL_TARGET_RESPONSE`, non-empty-response assertion, registry-only, pytest-node, mapping-only, hash-only, or metadata-only rows in the accepted count.

## Self-Audit

1. One thing this artifact does: closes the BEAAA-14096 contract-anchor mismatch by replacing the excluded rows with BEAAA-14142 rows anchored to `are-scanner-api-v1@v1.0`.
2. Audience and next action: Auditor / parent verifier can inspect the attached manifest and update BEAAA-13914 accepted count if the seven gates are accepted.
3. Supreme Law: respected; this is execution evidence only and emits no BackBond Score.
4. Score metadata: no score emitted; each row carries `scanner_version`, `corpus_version`, `model_versions`, and `seed`.
5. Contract change: none; N=5 calibration delta not applicable.
6. Rollback: exclude `artifacts/beaaa-14142/manifest.json`; parent count returns to 910 and these 270 rows remain excluded.
7. LLM judge pinning: no judge calls.
8. Glossary check: passed; BackBond canonical terms used.
9. Carrier Rule: no carrier named.
10. CEO / Underwriter critique pre-empted: contract anchor is corrected to v1.0; deploy is explicitly not applicable because no code path changed.
