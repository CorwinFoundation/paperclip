---
artifact_type: report
owner: scanner_engineer
persona_audience: internal
phase: 2
canonical_terms_only: true
focus_claim: "BEAAA-14096 restores BackBond Scanner real-agent execution evidence by adding authenticated Retell target traces that fixture rows cannot count."
contracts_referenced: ["are-scanner-api-v1", "scanner-implementation-supervision-v1"]
ticket_refs: ["BEAAA-14096", "BEAAA-14092", "BEAAA-13914"]
proof_points_cited: ["artifacts/beaaa-14096/manifest.json", "artifacts/beaaa-14096/manifest.signature.json"]
version: 0.1
prior_version: null
self_audit_passed: true
escalations_noted: ["Rule-execution under scanner-implementation-supervision-v1.1: live execution/evidence packaging only; no rubric, scoring, judge, API-shape, corpus-semantic, or tamper-resistance change."]
---

# BEAAA-14096 Real-Agent Execution Batch

BLUF: executed 270 unique BackBond Scanner cases against the approved BackBond-owned Retell synthetic support agent. Countable additional real-agent cases: 270. Target calls: 270 create-chat + 270 create-chat-completion. Judge calls: 0.

- Started: `2026-07-14T07:11:25+00:00`
- Completed: `2026-07-14T07:12:50+00:00`
- Target identity: `retell:agent_1e7015ae5f87ea825a3d1fac11`
- Non-secret service identifier: `api.retellai.com/create-chat + /create-chat-completion`
- Contract: `are-scanner-api-v1@v1.3.0`
- scanner_version: `0.5.0`
- corpus_version: `beaaa14092-real-agent-recovery@2026-07-14`
- probe-set-version: `beaaa14092-c-retell-real-agent-cases@0.1.0`
- rubric_point_id: `ROBUSTNESS.PROMPT_INJECTION.DIRECT, ROBUSTNESS.DATA_EXFILTRATION.SECRET_DISCLOSURE, OPS.SCOPE_CONTROL.SYNTHETIC_SUPPORT, BIAS_FAIRNESS.AUTONOMOUS_DECISION_CONSISTENCY`
- model_versions.primary: `retell:agent_1e7015ae5f87ea825a3d1fac11:gpt-4.1-mini:temperature-0`
- model_versions.judges: `[]`
- seed: `0`
- Manifest: `artifacts/beaaa-14096/manifest.json`
- Signed/hashed verification: `artifacts/beaaa-14096/manifest.signature.json`

| Family | Count |
| --- | ---: |
| `autonomous_decision_consistency` | 45 |
| `direct_prompt_injection` | 45 |
| `restricted_action_refusal` | 90 |
| `synthetic_support_scope` | 90 |

| Verdict | Count |
| --- | ---: |
| pass | 97 |
| fail | 173 |
| partial | 0 |
| unresolved | 0 |

Exclusions: zero localhost, `127.0.0.1`, mock, echo, replay, staging-fixture, `LOCAL_TARGET_RESPONSE`, generated/prewritten target response, non-empty-response assertion, registry-only, pytest-node, mapping-only, hash-only, or metadata-only rows are counted. Every counted row carries a concrete prompt, authenticated target-call proof hash, raw Retell chat response/action trace, deterministic oracle, terminal/applicable/attempted/evidenced flags, and a case-level evidence ref.

GitHub/CI/deploy provenance: no production deploy, no PR, no CI run, and no code path change is required for this evidence batch. The source workspace commit at execution time is recorded in the manifest; the new artifacts are evidence outputs under `artifacts/beaaa-14096/`.

N=5 calibration delta: not applicable to scoring because this batch emits no BackBond Score and changes no Scanner rule. Operational delta recorded as max total 0 / max subscore 0 for code and scoring surfaces.

FAL/house-style audit: internal artifact, canonical terms checked, no external-bound brand gate required, no carrier/customer naming beyond the BackBond-owned Retell synthetic support target.
