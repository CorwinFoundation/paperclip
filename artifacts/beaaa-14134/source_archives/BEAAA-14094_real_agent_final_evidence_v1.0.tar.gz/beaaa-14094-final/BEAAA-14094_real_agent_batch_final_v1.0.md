---
artifact_type: report
owner: scanner_engineer
persona_audience: internal
phase: 1
canonical_terms_only: true
focus_claim: "BEAAA-14094 completes the real-agent BackBond Scanner execution evidence needed to recover the BEAAA-13914 coverage count without counting fixtures or replay rows."
contracts_referenced: ["are-scanner-api-v1@v1.0", "scanner-implementation-supervision-v1@v1.1"]
ticket_refs: ["BEAAA-14094", "BEAAA-14092", "BEAAA-14087", "BEAAA-14127"]
proof_points_cited: ["artifacts/beaaa-14094-final/manifest.final.jsonl", "artifacts/beaaa-14094-final/summary.final.json", "artifacts/beaaa-14094-final/case_evidence/"]
version: 1.0
prior_version: "BEAAA-14094_real_agent_batch_partial_blocked_v0.1.md"
self_audit_passed: true
escalations_noted: ["BEAAA-14127 restored Retell capacity for the same approved target; no replacement target was used."]
---

# BEAAA-14094 Real-Agent Batch Final Report

BLUF: all 275 assigned BackBond Scanner cases executed against the approved BackBond-owned Retell demo agent. The final packet contains 275 unique case rows, raw target traces, deterministic verdict provenance, and a reconciled manifest with zero seven-gate failures.

## Classification

Rule-execution under `scanner-implementation-supervision-v1@v1.1`: this executed probes inside existing `rubric_point_id` families. It changed no rubric point, pillar weight, scoring math, judge model, tamper-resistance posture, or BackBond Scanner API output shape. CTO co-sign is not required.

## Target

| Field | Value |
|---|---|
| target_identity | `backbond-approved-demo-agent-v1` |
| non-secret service identifier | `retell:agent_1e7015ae5f87ea825a3d1fac11` |
| target_type | `real_agent` |
| endpoints | `api.retellai.com/create-chat`; `api.retellai.com/create-chat-completion` |
| model_versions.primary | `retell:agent_1e7015ae5f87ea825a3d1fac11:gpt-4.1-mini:temperature-0` |
| model_versions.judges | `[]` |

Authentication proof is retained only as `authorization_sha256` in each raw request row. No token value is stored.

## Execution Totals

| Metric | Count |
|---|---:|
| assigned cases | 275 |
| completed unique cases | 275 |
| remaining cases | 0 |
| target calls represented by counted rows | 335 |
| target calls including prior failed attempts before capacity restore | 335 |
| judge calls | 0 |
| pass | 259 |
| fail | 16 |
| partial | 0 |
| unresolved | 0 |

## Family Split

| Family | Completed |
|---|---:|
| direct prompt injection | 80 |
| indirect prompt injection | 80 |
| multi-turn prompt injection | 60 |
| tool misuse unauthorized action | 55 |

## Required Metadata

| Field | Value |
|---|---|
| scanner_version | `1.2.0` |
| corpus_version | `scanner-test-registry-baseline-2026-07-13` |
| probe-set-version | `beaaa14092-a-real-agent-retell@2026-07-14` |
| rubric_point_id | `ROBUSTNESS.PROMPT_INJECTION.DIRECT; ROBUSTNESS.PROMPT_INJECTION.INDIRECT; ROBUSTNESS.PROMPT_INJECTION.MULTI_TURN; ROBUSTNESS.TOOL_MISUSE.UNAUTHORIZED_CALL` |
| N=5 calibration delta | `not_applicable_execution_evidence_only_no_score_path_change` |
| cto_cosign_ref | `not_required_rule_execution` |
| contract anchor | `are-scanner-api-v1@v1.0` |
| seed | `0` |

## Evidence

| Artifact | Value |
|---|---|
| final manifest | `artifacts/beaaa-14094-final/manifest.final.jsonl` |
| final manifest SHA-256 | `6bc8f66b5ceb6e5ed67d24a872b10128f50e46f70f619a027a17c656cef2c14c` |
| final summary | `artifacts/beaaa-14094-final/summary.final.json` |
| final case evidence directory | `artifacts/beaaa-14094-final/case_evidence/` |
| prior 241-case packet SHA-256 | `179c67cc00ab9e18236e79c4043adaab5c8274fea04c117b099e2c01ae59e624` |
| generator | `scripts/beaaa14094_execute_real_agent_cases.py` |
| git provenance | `github://CorwinFoundation/are-scanner@19ed1516551930dc5fd1617a682f59bcf24f65b7` |
| PR | none |
| CI status | not run; no production code merge or deploy attempted |
| deployed digest | not applicable |

Seven-gate verification: `gate_failures=[]`; 275 / 275 rows carry prompt/action, expected behavior or oracle, named real-agent target, raw request/response trace, deterministic verdict provenance, reconciled manifest booleans, and GitHub provenance.

## Explicit Exclusions

No completed row is counted from localhost, `127.0.0.1`, mock, echo, staging fixture, replay, generated target responses, prewritten target responses, non-empty-response assertions, registry-only rows, pytest nodes, mappings, hashes, or metadata-only evidence.

## FAL Audit

Pass. Internal audience; no external Brand Backbone gate required; no customer or carrier named; no premium, coverage, legal, or capacity commitment; canonical BackBond terms used.

## Rollback

If any row is later found to fail BEAAA-14087, publish a corrected manifest excluding that row and decrement only the affected completed-case count. The excluded row remains in evidence with `evidenced=false` or an explicit exclusion reason; do not silently delete raw traces.
