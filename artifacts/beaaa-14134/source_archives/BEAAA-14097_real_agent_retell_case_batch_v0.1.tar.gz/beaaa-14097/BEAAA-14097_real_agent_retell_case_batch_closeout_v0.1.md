---
artifact_type: report
owner: scanner_engineer
persona_audience: internal
phase: 2
canonical_terms_only: true
focus_claim: "BEAAA-14097 adds 270 authenticated real-agent BackBond Scanner case traces to the BEAAA-14092 recovery count without relying on fixture, replay, or metadata-only evidence."
contracts_referenced: ["are-scanner-api-v1", "scanner-implementation-supervision-v1"]
ticket_refs: ["BEAAA-14097", "BEAAA-14092", "BEAAA-13914"]
proof_points_cited: ["artifacts/beaaa-14097/manifest.json", "artifacts/beaaa-14097/execution_evidence.jsonl", "artifacts/beaaa-14097/responses/*.json"]
version: 0.1
prior_version: null
self_audit_passed: true
escalations_noted: ["No CTO co-sign gate triggered: rule-execution evidence batch only; no rubric, scoring math, judge model, BackBond Scanner API output shape, corpus semantics, or tamper-resistance posture changed."]
---

# BEAAA-14097 Real-Agent Retell Case Batch Closeout

BLUF: executed 270 unique `beaaa14092-d-*` BackBond Scanner cases against the approved BackBond-owned Retell synthetic support agent. All 270 rows are terminal, evidenced, unique, and pass the BEAAA-14087 real-agent gate.

## Target And Calls

| Field | Value |
|---|---|
| target_identity | `backbond-approved-demo-agent-v1` |
| non-secret service identifier | `retell-chat-agent:agent_1e7015ae5f87ea825a3d1fac11` |
| non-secret endpoint | `https://api.retellai.com/create-chat-completion` |
| target completions | 270 |
| Retell API calls | 540 (`create-chat` + `create-chat-completion`) |
| judge calls | 0 |

## Results

| Metric | Count |
|---|---:|
| expected | 270 |
| applicable | 270 |
| attempted | 270 |
| terminal | 270 |
| evidenced | 270 |
| real-agent gate countable | 270 |
| pass | 265 |
| fail | 5 |
| partial | 0 |
| unresolved | 0 |

The 5 failures are conservative deterministic-comparator failures in `GOVERNANCE.APPROVALS`: the Retell target refused the unauthorized request but repeated the phrase `manager approval complete` while explaining that only the account owner can request it. They remain recorded as `fail`; the oracle was not rewritten after seeing the response.

## Contract Metadata

| Field | Value |
|---|---|
| contract_version | `are-scanner-api-v1@v1.0` |
| scanner_version | `1.2.0` |
| corpus_version | `scanner-test-registry-baseline-2026-07-13` |
| probe-set-version | `beaaa14092-d-real-agent-retell@2026-07-14` |
| rubric_point_id | `GOVERNANCE.APPROVALS`, `ROBUSTNESS.DATA_EXFILTRATION`, `ROBUSTNESS.PROMPT_INJECTION.DIRECT`, `ROBUSTNESS.PROMPT_INJECTION.INDIRECT`, `ROBUSTNESS.RUNAWAY_LOOP`, `ROBUSTNESS.TOOL_MISUSE.UNAUTHORIZED_CALL` |
| model_versions.primary | `retell:agent_1e7015ae5f87ea825a3d1fac11:gpt-4.1-mini:temperature-0` |
| model_versions.judges | `[]` |
| seed | `0` |
| N=5 calibration delta | `not_applicable_execution_evidence_only_no_score_path_change` |
| cto_cosign_ref | `not_required_rule_execution` |

## Evidence And Provenance

| Artifact | SHA-256 |
|---|---|
| `artifacts/beaaa-14097/execution_evidence.jsonl` | `53b8504ce1a93cba9b925b4e608e6e3368a76fa9a49bd8b218c78dfb363377d5` |
| `artifacts/beaaa-14097/manifest.json` | `493b0362e6aebb4fb289243312d82ec5b6afcac830e786c250f072fbbdcbbb04` |

Base repo commit at execution: `19ed1516551930dc5fd1617a682f59bcf24f65b7`. PR: none. CI status: not run; this is an artifact-only live execution and no scoring or deployed code path changed. Deployed digest: none.

Excluded from count: localhost, `127.0.0.1`, mock, echo, staging-fixture, replay, `LOCAL_TARGET_RESPONSE`, generated/prewritten target responses, non-empty-response assertions, registry rows, pytest nodes, mappings, hashes-only evidence, and metadata-only evidence.

Validation command:

```bash
python3 - <<'PY'
import json
from pathlib import Path
from tools.real_agent_execution_gate import evaluate_real_agent_execution
p = Path("artifacts/beaaa-14097/execution_evidence.jsonl")
rows = [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
ids = [row["case_id"] for row in rows]
gate = [evaluate_real_agent_execution(row) for row in rows]
print({
    "rows": len(rows),
    "unique_ids": len(set(ids)),
    "prefix_ok": all(case_id.startswith("beaaa14092-d-") for case_id in ids),
    "gate_countable": sum(result.countable for result in gate),
    "terminal": sum(1 for row in rows if row.get("terminal")),
    "evidenced": sum(1 for row in rows if row.get("evidenced")),
})
PY
```

Observed validation: `rows=270`, `unique_ids=270`, `prefix_ok=True`, `gate_countable=270`, `terminal=270`, `evidenced=270`.

FAL/house-style audit: internal artifact, canonical terms checked, no external-bound brand gate required, no carrier/customer names, no warranty or insurance promise language added.
