---
artifact_type: report
owner: scanner_engineer
persona_audience: internal
phase: 2
canonical_terms_only: true
focus_claim: "BEAAA-14095 restores BackBond Scanner real-agent execution evidence with 275 authenticated Retell target traces that fixture rows cannot count."
contracts_referenced: ["are-scanner-api-v1", "scanner-implementation-supervision-v1"]
chains_referenced: []
brand_backbone_version: null
brand_backbone_sha256: null
brand_backbone_verified: null
brand_backbone_scope: "not_applicable_internal"
"scanner_version": "0.5.0"
"corpus_version": "beaaa14092-real-agent-recovery@2026-07-14"
"probe-set-version": "beaaa14092-b-retell-real-agent-cases@0.1.0"
"rubric_point_id": "ROBUSTNESS.HALLUCINATED_ACTIONS.UNAUTHORIZED_COMMITMENT, ROBUSTNESS.FACTUALITY.SUPPORT_GROUNDING, ROBUSTNESS.DATA_EXFILTRATION.SECRET_DISCLOSURE, ROBUSTNESS.REFUSAL_BOUNDARY.OUT_OF_SCOPE_ACTION"
"N=5 calibration delta": "max_total_delta=0; max_subscore_delta=0; score path unchanged; no BackBond Score emitted"
"cto_cosign_ref": "not_required_rule_execution"
"merged_sha_on_canon_master_at_close": "not_applicable_artifact_only_no_code_commit"
upstream_eval_version: null
contract_version: "are-scanner-api-v1@v1.0"
classification: "rule-execution: smoke/test execution for an existing operation"
n5_calibration_delta: "max_total_delta=0; max_subscore_delta=0; no score emitted; no scanner rule changed"
fal_audit: "passed_internal_house_style_canonical_terms_no_external_brand_gate"
case_manifest_sha256: "11b463c4e2961b7ee59a0b077ab3be77323ef38ec5c85d4012f3d5b4e1aa123e"
proof_points_cited: ["artifacts/beaaa-14095-complete/manifest.json", "artifacts/beaaa-14095-complete/manifest.signature.json"]
version: 0.2
prior_version: "artifacts/beaaa-14095-live/BEAAA-14095_real_agent_275_case_execution_v0.1.md"
self_audit_passed: true
escalations_noted: []
---

# BEAAA-14095 Real-Agent Execution Batch Complete

BLUF: BEAAA-14095 is complete. The batch now has 275 terminal evidenced real-agent cases against the approved BackBond-owned Retell synthetic support agent; no fixture, replay, localhost, mock, metadata-only, or unresolved transport row is counted.

## Target And Contract

| Field | Value |
| --- | --- |
| Target identity | `retell:agent_1e7015ae5f87ea825a3d1fac11` |
| Non-secret service identifier | `api.retellai.com/create-chat + /create-chat-completion` |
| Contract | `are-scanner-api-v1@v1.0` |
| scanner_version | `0.5.0` |
| corpus_version | `beaaa14092-real-agent-recovery@2026-07-14` |
| probe-set-version | `beaaa14092-b-retell-real-agent-cases@0.1.0` |
| model_versions.primary | `retell:agent_1e7015ae5f87ea825a3d1fac11:gpt-4.1-mini:temperature-0` |
| model_versions.judges | `[]` |
| seed | `0` |
| Classification | Rule execution, per `scanner-implementation-supervision-v1.1` smoke/test execution row |
| cto_cosign_ref | `not_required_rule_execution` |

## Count Reconciliation

| Metric | Count |
| --- | ---: |
| Expected unique BEAAA-14092-B cases | 275 |
| Terminal/countable cases | 275 |
| Pass | 222 |
| Fail | 53 |
| Partial | 0 |
| Unresolved | 0 |
| Judge calls | 0 |
| Initial Retell API calls | 550 |
| Resume Retell API calls | 506 |
| Total Retell API calls across both waves | 1056 |

## Evidence

- Manifest: `artifacts/beaaa-14095-complete/manifest.json`
- Manifest SHA-256: `11b463c4e2961b7ee59a0b077ab3be77323ef38ec5c85d4012f3d5b4e1aa123e`
- Signature: `artifacts/beaaa-14095-complete/manifest.signature.json`
- Raw case evidence directory: `artifacts/beaaa-14095-complete/raw`
- GitHub provenance: `github://CorwinFoundation/are-scanner@19ed1516551930dc5fd1617a682f59bcf24f65b7`
- PR: `none`
- CI status: `not_run_artifact_only_no_code_path_change`
- Deployed digest: `none`

Exclusions: zero localhost, `127.0.0.1`, mock, echo, replay, staging-fixture, `LOCAL_TARGET_RESPONSE`, generated/prewritten target response, non-empty-response assertion, registry-only, pytest-node, mapping-only, hash-only, or metadata-only rows are counted. Every counted row carries a concrete prompt, authenticated target-call proof hash, raw Retell chat response/action trace, deterministic oracle, terminal/applicable/attempted/evidenced flags, and a case-level evidence ref.

N=5 calibration delta: not applicable to scoring because this batch emits no BackBond Score and changes no Scanner rule. Operational delta recorded as max total 0 / max subscore 0 for code and scoring surfaces.

FAL/house-style audit: internal artifact, canonical terms checked, no external-bound brand gate required, no carrier/customer naming beyond the BackBond-owned Retell synthetic support target.
